import java.awt.Color;
import java.awt.Graphics;

/**
 * Represents a single cell in the cave grid.
 * Each cell has a depth and can be part of the diver's escape route.
 */
public class CaveCell {
    private int depth;
    private boolean isPartOfEscapeRoute;

    /**
     * Constructs a CaveCell object with the specified depth.
     * The cell is initially not part of the escape route.
     *
     * @param row The row index of the cell in the cave grid (not used in this class).
     * @param col The column index of the cell in the cave grid (not used in this class).
     * @param depth The depth of the cave cell, determining its color.
     */
    public CaveCell(int row, int col, int depth) {
        this.depth = depth;
        this.isPartOfEscapeRoute = false;
    }

    /**
     * Gets the depth of this cave cell.
     * 
     * @return The depth value of the cell.
     */
    public int getDepth() {
        return depth;
    }

    /**
     * Checks if this cell is part of the escape route.
     * 
     * @return True if the cell is part of the escape route, false otherwise.
     */
    public boolean isPartOfEscapeRoute() {
        return isPartOfEscapeRoute;
    }

    /**
     * Sets whether this cell is part of the escape route.
     *
     * @param isPartOfEscapeRoute True if the cell should be marked as part of the escape route, false otherwise.
     */
    public void setPartOfEscapeRoute(boolean isPartOfEscapeRoute) {
        this.isPartOfEscapeRoute = isPartOfEscapeRoute;
    }

    /**
     * Draws the cave cell on the screen.
     * If the cell is part of the escape route, it is drawn in red; otherwise, it is drawn in a shade of blue
     * corresponding to its depth.
     * 
     * @param g The graphics context used for drawing.
     * @param x The x-coordinate of the top-left corner of the cell.
     * @param y The y-coordinate of the top-left corner of the cell.
     * @param size The size (width and height) of the cell.
     */
    public void draw(Graphics g, int x, int y, int size) {
        if (isPartOfEscapeRoute) {
            g.setColor(Color.RED);  // Draw in red if part of the escape route
        } else {
            // Calculate blue color based on depth
            int blueShade = Math.max(0, Math.min(255, 255 - depth * 25));
            g.setColor(new Color(0, 0, blueShade));
        }
        g.fillRect(x, y, size, size);  // Draw the cell as a filled rectangle
        g.setColor(Color.BLACK);       // Draw the border of the cell
        g.drawRect(x, y, size, size);  // Draw the cell border

        // Draw the depth number in the top-left corner of the cell
        g.setColor(Color.WHITE);
        g.drawString(String.valueOf(depth), x + 5, y + 15);  // Position the text in the top-left corner
    }
}
