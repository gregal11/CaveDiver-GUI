// Alec LeBlanc
// Cave Diver Midterm
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;  // Import for the dialog pop-up
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

/**
 * The main application class for the Cave Diver game.
 * It sets up the user interface and handles interaction between the user and the escape algorithm.
 */
public class CaveEscapeApp extends JFrame {
    private static final long serialVersionUID = 1L;
    private CaveGrid caveGrid;
    private JTextField depthInput;
    private JLabel statusLabel;

    /**
     * Constructs the CaveEscapeApp GUI.
     * Initializes the window, cave grid, input fields, buttons, and labels.
     */
    public CaveEscapeApp() {
        setTitle("Cave Diver - Find an Escape Route");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600);
        setLayout(new BorderLayout());

        // Top label with instructions
        JLabel titleLabel = new JLabel("The diver begins in the upper-left corner and escapes by reaching the lower-right corner.", SwingConstants.CENTER);
        add(titleLabel, BorderLayout.NORTH);

        // Cave grid in the center
        caveGrid = new CaveGrid();
        add(caveGrid, BorderLayout.CENTER);

        // Bottom panel
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JLabel depthLabel = new JLabel("Enter the diver's depth rating:");
        bottomPanel.add(depthLabel);

        depthInput = new JTextField(5);
        bottomPanel.add(depthInput);

        // Escape button
        JButton escapeButton = new JButton("Escape");
        escapeButton.addActionListener(e -> onEscapeButtonClick());
        bottomPanel.add(escapeButton);

        // New Cave button
        JButton newCaveButton = new JButton("New Cave");
        newCaveButton.addActionListener(e -> caveGrid.generateNewCave());
        bottomPanel.add(newCaveButton);

        statusLabel = new JLabel(" ");
        bottomPanel.add(statusLabel);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    /**
     * Handles the "Escape" button click event.
     * This method gets the diver's depth rating input, runs the escape algorithm, and updates the UI accordingly.
     * If no escape route is found, it shows a dialog pop-up with an error message.
     */
    private void onEscapeButtonClick() {
        try {
            int depthRating = Integer.parseInt(depthInput.getText());
            EscapeAlgorithm escape = new EscapeAlgorithm(caveGrid);

            // Check if an escape route is found
            if (escape.findEscapeRoute(0, 0, depthRating)) {
                statusLabel.setText("Escape route found!");
            } else {
                statusLabel.setText("No escape route found.");

                // Display pop-up dialog when no route is found
                JOptionPane.showMessageDialog(this,
                    "No escape route found!",
                    "Ouch",
                    JOptionPane.ERROR_MESSAGE);
            }

            caveGrid.repaint();  // Refresh the grid to show any changes
        } catch (NumberFormatException ex) {
            // Handle invalid input for depth rating
            statusLabel.setText("Please enter a valid depth rating.");
        }
    }

    /**
     * The main method to launch the application.
     * It uses SwingUtilities.invokeLater to ensure that the UI is created and updated on the event-dispatching thread.
     *
     * @param args Command-line arguments (not used).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CaveEscapeApp app = new CaveEscapeApp();
            app.setVisible(true);
        });
    }
}
