import java.awt.Graphics;
import java.util.Random;

import javax.swing.JComponent;

/**
 * Represents the grid of the cave in which the diver tries to escape.
 * The grid consists of a 10x10 array of CaveCell objects.
 */
public class CaveGrid extends JComponent {
    private static final long serialVersionUID = 1L;
    private CaveCell[][] grid;
    private final int CELL_SIZE = 50;
    private final int GRID_SIZE = 10;

    /**
     * Constructs a CaveGrid and generates a new random cave.
     */
    public CaveGrid() {
        generateNewCave();
    }

    /**
     * Generates a new cave with random depths for each cell.
     * The depths range from 0 to 9 and determine the color of each cave cell.
     */
    public void generateNewCave() {
        Random rand = new Random();
        grid = new CaveCell[GRID_SIZE][GRID_SIZE];
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                int depth = rand.nextInt(10);  // Random depth between 0 and 9
                grid[row][col] = new CaveCell(row, col, depth);
            }
        }
        repaint();  // Repaint the grid to reflect the new cave
    }

    /**
     * Paints the cave grid by drawing each CaveCell.
     * This method is called automatically by the system whenever the component needs to be rendered.
     * 
     * @param g The graphics context used for drawing the grid and cells.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                int x = col * CELL_SIZE;
                int y = row * CELL_SIZE;
                grid[row][col].draw(g, x, y, CELL_SIZE);
            }
        }
    }

    /**
     * Retrieves the CaveCell at a specified row and column in the grid.
     *
     * @param row The row index of the cell.
     * @param col The column index of the cell.
     * @return The CaveCell at the specified location.
     */
    public CaveCell getCell(int row, int col) {
        return grid[row][col];
    }
}
