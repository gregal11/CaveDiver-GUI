import java.awt.Component;

/**
 * Implements the recursive algorithm for finding an escape route in the cave.
 * The diver starts at the top-left corner and attempts to reach the bottom-right corner
 * while adhering to the diver's depth rating and air supply constraints.
 */
public class EscapeAlgorithm {
    private CaveGrid cave;
    private int air;

    /**
     * Constructs an EscapeAlgorithm to find a route in the given cave grid.
     * The diver has 20 air units initially, and each move consumes 1 unit.
     *
     * @param caveGrid The cave grid component on which the escape algorithm operates.
     */
    public EscapeAlgorithm(Component caveGrid) {
        this.cave = (CaveGrid) caveGrid;
        this.air = 20;  // Diver has 20 air units
    }

    /**
     * Recursively searches for an escape route for the diver.
     * The diver can only move down or right, and the move must be within the air limit and the diver's depth rating.
     * If an escape route is found, the cells on the route are marked as part of the escape route.
     *
     * @param row The current row of the diver.
     * @param col The current column of the diver.
     * @param depthRating The diver's depth rating, which limits the maximum depth of cells the diver can enter.
     * @return True if an escape route is found, false otherwise.
     */
    public boolean findEscapeRoute(int row, int col, int depthRating) {
        // Base case: If the diver reaches the bottom-right corner, mark the cell and return true
        if (row == 9 && col == 9) {
            cave.getCell(row, col).setPartOfEscapeRoute(true);
            return true;
        }

        // If out of bounds or out of air, return false
        if (row >= 10 || col >= 10 || air <= 0) {
            return false;
        }

        // Get the current cell
        CaveCell currentCell = cave.getCell(row, col);

        // If the cell's depth exceeds the depth rating or it's already part of the escape route, return false
        if (currentCell.getDepth() > depthRating || currentCell.isPartOfEscapeRoute()) {
            return false;
        }

        // Use one unit of air and mark the current cell as part of the escape route
        air--;
        currentCell.setPartOfEscapeRoute(true);

        // Try moving right
        if (findEscapeRoute(row, col + 1, depthRating)) {
            return true;
        }

        // Try moving down
        if (findEscapeRoute(row + 1, col, depthRating)) {
            return true;
        }

        // If neither direction leads to an escape, backtrack: unmark the current cell and restore air
        currentCell.setPartOfEscapeRoute(false);
        air++;
        return false;
    }
}
